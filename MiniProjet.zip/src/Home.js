import { useNavigate } from "react-router-dom";
import "./styles.css";
import img from "./desktop-pc.png";

export const Home = (props) => {
  const navigate = useNavigate();
  return (
    <div className="App">
      <img src={img} alt="" />
      <h1>Welcome To our Application</h1>
      <h4>
        We are <b> Rania , Ines , Djoumana </b>
      </h4>
      <br />
      <br />
      <label class="home">you can choose one of the option :</label>
      <br /> <br />
      <button id="btn" onClick={() => navigate("./Blog")}>
        Blog
      </button>
      <button id="btn" onClick={() => navigate("./Contact")}>
        Contact
      </button>
      <br />
    </div>
  );
};
export default Home;
